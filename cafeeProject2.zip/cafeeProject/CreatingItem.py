from io import BytesIO
from tkinter import *
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
from random import randint
from Database import Database


class CreatingItem:
    def __init__(self, root):
        self.root = root
        self.root.title("Creating Item Page")

        def convertToBinaryData(filename):

            # Convert binary format to images
            # or files data
            with open(filename, 'rb') as file:
                blobData = file.read()
            return blobData

        def save_items():
            if p1.get()=="" or p2.get()=="" or p3.get()=="" or p6.get()=="":
                messagebox.showinfo("Message", "Fill up the blanks...")
            else:
                db = Database()
                conn = db.getConnected()
                mycursor = conn.cursor()
                sql = "INSERT into items (name,stock_qty,price,photo_name,photo_data) values(?,?,?,?,?)"
                name=p1.get()
                stock_qty=p2.get()
                price=p3.get()
                photo_name=p6.get()

                # binary data
               #image = Image.open(filename)  # Read the Image

                photo_data = convertToBinaryData(filename)
                file_like = BytesIO(photo_data)
                image=Image.open(file_like)
                resize_image = image.resize((250, 200))


                data_tuple = (name, stock_qty,price,photo_name,resize_image.tobytes())

                # using cursor object executing our query
                mycursor.execute(sql, data_tuple)

                messagebox.showinfo("Message", "Successfully Saved new Item...")
                conn.commit()
                conn.close()

        def show_photo():
            global filename
            filename = filedialog.askopenfilename(initialdir="/", title="Select an Image")

            image = Image.open(filename)  # Read the Image

            resize_image = image.resize((250, 200))

            show_img = ImageTk.PhotoImage(resize_image)

            var_photo = Label(p7, image=show_img)
            file_name=filename.split("/")
            ran_nos=randint(10000,99999)
            p6.insert(END,str(ran_nos)+"_"+file_name[len(file_name)-1])
            p7.config(image=show_img, width=200, height=200)

            var_photo.image = show_img
            var_photo.pack()

        img1 = PhotoImage(file="img/img4.png")
        pic1 = Label(image=img1, bg='#5A3737')
        pic1.photo = img1
        pic1.place(x=0, y=0)

        psr1 = PanedWindow(width=204, height=470, bg='#5A3737')
        psr1.place(x=0, y=375)

        users = Label(psr1, text='USERS', font='Inter 20', fg='white', bg='#5A3737')
        users.place(x=50, y=100)

        items = Label(psr1, text='ITEMS', font="Inter 20", fg='white', bg='#5A3737')
        items.place(x=55, y=175)

        orders = Label(psr1, text='ORDERS', font='Inter 20', fg='white', bg='#5A3737')
        orders.place(x=40, y=250)

        settings = Label(psr1, text='SETTINGS', font="Inter 20", fg='white', bg='#5A3737')
        settings.place(x=30, y=325)

        logout = Label(psr1, text='LOGOUT', font="Inter 20 bold", fg='white', bg='#5A3737')
        logout.place(x=40, y=400)

        psr2 = PanedWindow(width=1500, height=120, bg='#5A3737')
        psr2.place(x=203, y=0)

        img2 = PhotoImage(file="img/img1.png")
        logo1 = Label(image=img2, bg='#5A3737')
        logo1.photo = img2
        logo1.place(x=230, y=20)

        img3 = PhotoImage(file="img/Screenshot 2024-01-30 160342.png")
        logo2 = Label(psr2, image=img3, bg='#5A3737')
        logo2.photo = img3
        logo2.place(x=1200, y=20)

        username = Label(psr2, text="MG MG", bg="#5A3737", fg='white')
        username.config(font='Inter 15')
        username.place(x=1190, y=80)

        title = Label(text="UNIQUE TEAHOUSE", bg="#5A3737", fg='white')
        title.config(font='Inter 30 bold')
        title.place(x=320, y=35)

        txt1 = Label(text="Item Category", fg='black')
        txt1.config(font="Inter 25 bold")
        txt1.place(x=250, y=150)

        subhead = Label(text='Create New Item', fg='black')
        subhead.config(font="Inter 20")
        subhead.place(x=250, y=210)

        txt2 = Label(text="Item Name", fg='black')
        txt2.config(font="Inter 15")
        txt2.place(x=620, y=270)

        txt3 = Label(text="stock", fg='black')
        txt3.config(font="Inter 15")
        txt3.place(x=620, y=320)

        txt4 = Label(text="Price", fg='black')
        txt4.config(font="Inter 15")
        txt4.place(x=620, y=370)

        txt5 = Label(text="ICON", fg='black')
        txt5.config(font="Inter 15")
        txt5.place(x=620, y=420)

        p1 = Entry(width=16, font='Inter 25', bg='silver')
        p1.place(x=850, y=270)

        p2 = Entry(width=16, font='Inter 25', bg='silver')
        p2.place(x=850, y=320)

        p3 = Entry(width=16, font='Inter 25', bg='silver')
        p3.place(x=850, y=370)

        p6 = Entry(width=16, font='Inter 25', bg='silver')
        p6.place(x=850, y=420)

        p7 = Button(width=40, height=15, bg='#CCCCCC')
        p7.place(x=850, y=470)

        browse = Button(text='BROWSE', font='Arial 14', width=10, height=2, bg='silver', command=show_photo)
        browse.place(x=1150, y=420)

        create = Button(text='CREATE', font='Arial 15', width=10, height=2, bg='silver',command=save_items)
        create.place(x=850, y=720)


if __name__ == "__main__":
    root = Tk()
    app = CreatingItem(root)
    root.geometry("1920x1080")
    root.mainloop()
