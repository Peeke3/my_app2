from tkinter import *
from Database import Database

class ItemPage:
    def __init__(self, root):

        self.root = root
        self.root.title("Item Page")

        def open_edit(id):
            print("row id = ",id)
            self.root.destroy()
            from EditPage import EditPage
            editpage = Tk()
            edit = EditPage(editpage,id)
            editpage.geometry("1920x1080")
            editpage.mainloop()


        img1 = PhotoImage(file="img/img4.png")
        pic1 = Label(image=img1, bg='#5A3737')
        pic1.photo = img1
        pic1.place(x=0, y=0)

        psr1 = PanedWindow(width=204, height=470, bg='#5A3737')
        psr1.place(x=0, y=375)

        users = Label(psr1, text='USERS', font='Inter 20', fg='white', bg='#5A3737')
        users.place(x=50, y=100)

        items = Label(psr1, text='ITEMS', font="Inter 20", fg='white', bg='#5A3737')
        items.place(x=55, y=175)

        orders = Label(psr1, text='ORDERS', font='Inter 20', fg='white', bg='#5A3737')
        orders.place(x=40, y=250)

        settings = Label(psr1, text='SETTINGS', font="Inter 20", fg='white', bg='#5A3737')
        settings.place(x=30, y=325)

        logout = Label(psr1, text='LOGOUT', font="Inter 20 bold", fg='white', bg='#5A3737')
        logout.place(x=40, y=400)

        psr2 = PanedWindow(width=1500, height=120, bg='#5A3737')
        psr2.place(x=203, y=0)

        img2 = PhotoImage(file="img/img1.png")
        logo1 = Label(image=img2, bg='#5A3737')
        logo1.photo = img2
        logo1.place(x=230, y=20)

        img3 = PhotoImage(file="img/Screenshot 2024-01-30 160342.png")
        logo2 = Label(psr2, image=img3, bg='#5A3737')
        logo2.photo = img3
        logo2.place(x=1200, y=20)

        username = Label(psr2, text="MG MG", bg="#5A3737", fg='white')
        username.config(font='Inter 15')
        username.place(x=1190, y=80)

        title = Label(text="UNIQUE TEAHOUSE", bg="#5A3737", fg='white')
        title.config(font='Inter 30 bold')
        title.place(x=320, y=35)

        txt1 = Label(text="Item Category", bg=None, fg='black')
        txt1.config(font="Inter 25 bold")
        txt1.place(x=250, y=150)

        btn1 = Button(text='Create New', width=15, font='Inter 20', fg = 'black', bg = 'silver')
        btn1.place(x=250,y=280)

        btn2 = Button(text='Delete All', width=15, font='Inter 20', fg='black', bg='silver')
        btn2.place(x=250, y=350)

        heading = Label(text="ID                 Name                  Qty              price              Photo              Action", font="Inter 18 bold")
        heading.place(x=600, y=220)

        db = Database()
        conn = db.getConnected()
        mycursor = conn.cursor()
        sql = "SELECT * from items"
        rows = mycursor.execute(sql)

        panel=0
        panel_x=590
        panel_y=280
        for row in rows:

            if panel%2==0:
                item_panel1 = PanedWindow(width=900, height=60, bg='#DCD3D3')
                item_panel1.place(x=panel_x, y=panel_y)

                id_lb = Label(item_panel1, text=row[0], bg='#DCD3D3', font='Inter 16')
                id_lb.place(x=10, y=15)

                name_lb = Label(item_panel1, text=row[1], bg='#DCD3D3', font='Inter 16')
                name_lb.place(x=120, y=15)

                qty_lb = Label(item_panel1, text=row[2], bg='#DCD3D3', font='Inter 16')
                qty_lb.place(x=345, y=15)

                price_lb = Label(item_panel1, text=row[3], bg='#DCD3D3', font='Inter 16')
                price_lb.place(x=485, y=15)

                photo_lb = Label(item_panel1, text=row[4], bg='#DCD3D3', font='Inter 12')
                photo_lb.place(x=590, y=15)

                edit_btn = Button(item_panel1, text='Edit', width=5, font='Inter 13', fg='black', bg='silver',command=lambda id=row[0]:open_edit(id))
                edit_btn.place(x=810, y=15)

            else:
                item_panel2 = PanedWindow(width=900, height=60, bg='#999292')
                item_panel2.place(x=panel_x, y=panel_y)

                id_lb = Label(item_panel2, text=row[0], bg='#999292', font='Inter 16')
                id_lb.place(x=10, y=15)

                name_lb = Label(item_panel2, text=row[1], bg='#999292', font='Inter 16')
                name_lb.place(x=120, y=15)

                qty_lb = Label(item_panel2, text=row[2], bg='#999292', font='Inter 16')
                qty_lb.place(x=345, y=15)

                price_lb = Label(item_panel2, text=row[3], bg='#999292', font='Inter 16')
                price_lb.place(x=485, y=15)

                photo_lb = Label(item_panel2, text=row[4], bg='#999292', font='Inter 12')
                photo_lb.place(x=590, y=15)

                edit_btn = Button(item_panel2, text='Edit', width=5, font='Inter 13', fg='black', bg='silver',command=lambda id=row[0]:open_edit(id))
                edit_btn.place(x=810, y=15)

            panel += 1
            panel_y += 60


if __name__ == "__main__":
    root = Tk()
    app = ItemPage(root)
    root.geometry("1920x1080")
    root.mainloop()