from tkinter import *
from tkinter import messagebox

from Database import Database

class SignupPage:
    def __init__(self, root):
        self.root = root
        self.root.title("Signup Page")

        def save():
            if e1.get()=='':
                messagebox.showinfo("Message", "Full name is empty...")
            elif e2.get()=='':
                messagebox.showinfo("Message", "Username is empty...")
            elif e3.get()=='':
                messagebox.showinfo("Message", "Password field is empty...")
            elif e4.get()=='':
                messagebox.showinfo("Message","Confirm Password is empty")
            elif e3.get()!=e4.get():
                messagebox.showinfo("Message", "Passwords mismatched...")
            else:
                db = Database()
                conn = db.getConnected()
                mycursor = conn.cursor()
                sql = "INSERT into users (fullname,username,password) values('"+e1.get()+"','"+e2.get()+"','"+e3.get()+"')"

                mycursor.execute(sql)
                messagebox.showinfo("Message", "Successfully registered...")
                conn.commit()
                conn.close()

                self.root.destroy()
                from LoginPage import LoginPage
                login = Tk()
                login_page = LoginPage(login)
                login.geometry("1920x1080")
                login.mainloop()

        p1 = PanedWindow(width=500,height=602,bg='#5A3737')
        p1.place(x=740,y=130)

        img1 = PhotoImage(file="img/img1.png")
        logo1 = Label(image=img1, bg='white')
        logo1.photo = img1
        logo1.place(x=300, y=35)

        title = Label(text="UNIQUE TEAHOUSE",bg="white",fg='#5A3737')
        title.config(font='Inter 30 bold')
        title.place(x=390, y=50)

        img2 = PhotoImage(file='img/img3.png')
        pic1 = Label(image=img2, bg="#5A3737")
        pic1.photo = img2
        pic1.place(x=300,y=130)

        txt1 = Label(p1, text="REGISTRATION",bg="#5A3737",fg='white')
        txt1.config(font='Inter 20 bold')
        txt1.place(x=263, y=40)

        img3 = PhotoImage(file="img/img5.png")
        logo2 = Label(p1,image=img3, bg='#5A3737')
        logo2.photo = img3
        logo2.place(x=200, y=30)

        e1 = Entry(p1, width=15, font='Inter 25 bold')
        e1.place(x=200, y=150)

        e2 = Entry(p1, width=15, font='Inter 25 bold')
        e2.place(x=200, y=230)

        e3 = Entry(p1, width=15, font='Inter 25 bold')
        e3.place(x=200, y=310)

        e4 = Entry(p1, width=15, font='Inter 25 bold')
        e4.place(x=200, y=390)

        b1 = Button(p1, width=25, text='REGISTER', font='Inter 17 bold', fg='grey',command=save)
        b1.place(x=80, y=500)

        txt2 = Label(p1, text="FULL NAME", bg="#5A3737", fg='white')
        txt2.config(font='Inter 12')
        txt2.place(x=90, y=150)

        img4 = PhotoImage(file="img/img6.png")
        logo3 = Label(p1, image=img4, bg='#5A3737')
        logo3.photo = img4
        logo3.place(x=57, y=147)

        txt3 = Label(p1, text="USERNAME", bg="#5A3737", fg='white')
        txt3.config(font='Inter 12')
        txt3.place(x=90, y=230)

        img5 = PhotoImage(file="img/img6.png")
        logo4 = Label(p1, image=img5, bg='#5A3737')
        logo4.photo = img5
        logo4.place(x=57, y=227)

        txt4 = Label(p1, text="PASSWORD", bg="#5A3737", fg='white')
        txt4.config(font='Inter 12')
        txt4.place(x=90, y=310)

        img6 = PhotoImage(file="img/img7.png")
        logo5 = Label(p1, image=img6, bg='#5A3737')
        logo5.photo = img6
        logo5.place(x=60, y=310)

        txt5 = Label(p1, text="CONFIRM", bg="#5A3737", fg='white')
        txt5.config(font='Inter 12')
        txt5.place(x=90, y=390)

        img7 = PhotoImage(file="img/img7.png")
        logo6 = Label(p1, image=img7, bg='#5A3737')
        logo6.photo = img7
        logo6.place(x=60, y=390)

        txt1 = Label(p1, text="PASSWORD", bg="#5A3737", fg='white')
        txt1.config(font='Inter 12')
        txt1.place(x=90, y=412)


if __name__ == "__main__":
    root = Tk()
    app = SignupPage(root)
    root.geometry("1920x1080")
    root.mainloop()