from tkinter import *


class EntryPage:
    def __init__(self, root):
        self.root = root
        self.root.title("Entry Page")

        p1 = PanedWindow(width=630, height=700, bg='#5A3737')
        p1.place(x=450, y=70)

        img1 = PhotoImage(file="img/img1.png")
        logo1 = Label(p1, image=img1, bg='#5A3737')
        logo1.photo = img1
        logo1.place(x=80, y=55)

        title = Label(p1, text="UNIQUE TEAHOUSE", bg="#5A3737", fg='white')
        title.config(font='Inter 30 bold')
        title.place(x=170, y=70)

        p2 = PanedWindow(p1, width=550, height=150, bg='#6E4848')
        p2.place(x=40, y=350)

        b1 = Button(width=15, text="LOGIN", font='Inter 20 bold', fg='#5A3737')
        b1.place(x=640, y=390)

        b2 = Button(width=15, text="SIGNUP", font='Inter 20 bold', fg='#5A3737')
        b2.place(x=640, y=540)


if __name__ == "__main__":
    root = Tk()
    app = EntryPage(root)
    root.geometry("1920x1080")
    root.mainloop()