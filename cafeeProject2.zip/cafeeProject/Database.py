import sqlite3


class Database:
    def getConnected(self):
        conn = sqlite3.connect('db1.db')
        return conn