from tkinter import *


class UserUpdatePage:
    def __init__(self, root):
        self.root = root
        self.root.title("User Update Page")

        img1 = PhotoImage(file="img/img4.png")
        pic1 = Label(image=img1, bg='#5A3737')
        pic1.photo = img1
        pic1.place(x=0, y=0)

        psr1 = PanedWindow(width=204, height=470, bg='#5A3737')
        psr1.place(x=0, y=375)

        home = Label(psr1, text='HOME', font='Inter 20 bold', fg='white', bg='#5A3737')
        home.place(x=55,y=25)

        myorders = Label(psr1, text='MY ORDERS', font="Inter 20", fg='white',bg='#5A3737')
        myorders.place(x=18,y=300)

        settings = Label(psr1, text='SETTINGS', font="Inter 20", fg='white', bg='#5A3737')
        settings. place(x=30,y=350)

        logout = Label(psr1, text='LOGOUT', font="Inter 20 bold", fg='white', bg='#5A3737')
        logout.place(x=40,y=400)

        psr2 = PanedWindow(width=1500, height=120, bg='#5A3737')
        psr2.place(x=203, y=0)

        img2 = PhotoImage(file="img/img1.png")
        logo1 = Label(image=img2, bg='#5A3737')
        logo1.photo = img2
        logo1.place(x=230, y=20)

        img3 = PhotoImage(file="img/Screenshot 2024-01-30 160342.png")
        logo2 = Label(psr2, image=img3, bg='#5A3737')
        logo2.photo = img3
        logo2.place(x=1200, y=20)

        username = Label(psr2, text="MG MG", bg="#5A3737", fg='white')
        username.config(font='Inter 15')
        username.place(x=1190, y=80)

        title = Label(text="UNIQUE TEAHOUSE", bg="#5A3737", fg='white')
        title.config(font='Inter 30 bold')
        title.place(x=320, y=35)

        txt1 = Label(text="Your Account", bg=None, fg='black')
        txt1.config(font="Inter 22 bold")
        txt1.place(x=250, y=150)

        txt2 = Label(text="Full Name", bg=None, fg='black')
        txt2.config(font="Inter 15")
        txt2.place(x=600, y=210)

        txt3 = Label(text="User Name", bg=None, fg='black')
        txt3.config(font="Inter 15")
        txt3.place(x=600, y=270)

        txt4 = Label(text="Current Password", bg=None, fg='black')
        txt4.config(font="Inter 15")
        txt4.place(x=600, y=330)

        txt5 = Label(text="New Password", bg=None, fg='black')
        txt5.config(font="Inter 15")
        txt5.place(x=600, y=390)

        txt6 = Label(text="Profile Picture", bg=None, fg='black')
        txt6.config(font="Inter 15")
        txt6.place(x=600, y=450)

        p1 = PanedWindow(width=300, height=50, bg='silver')
        p1.place(x=850, y=200)

        p2 = PanedWindow(width=300, height=50, bg='silver')
        p2.place(x=850, y=260)

        p3 = PanedWindow(width=300, height=50, bg='silver')
        p3.place(x=850, y=320)

        p4 = PanedWindow(width=300, height=50, bg='silver')
        p4.place(x=850, y=380)

        p6 = PanedWindow(width=150, height=150, bg='silver')
        p6.place(x=850, y=440)

        p7 = PanedWindow(width=130, height=50, bg='silver')
        p7.place(x=1020, y=440)

        browse = Label(p7, text = 'Browse', bg='silver', fg='black', font='Inter 18')
        browse.place(x=22,y=7)

        p8 = PanedWindow(width=200, height=70, bg='silver')
        p8.place(x=850, y=600)

        update = Label(p8, text='Update', bg='silver', fg='black', font='Inter 22')
        update.place(x=47, y=13)


if __name__ == "__main__":
    root = Tk()
    app = UserUpdatePage(root)
    root.geometry("1920x1080")
    root.mainloop()